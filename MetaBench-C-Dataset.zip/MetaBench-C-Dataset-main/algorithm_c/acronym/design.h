#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char *abbreviate(const char *phrase);

#endif
