#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <assert.h>

#define MAX_ADALINE_ITER 1000
#define ADALINE_ACCURACY 0.01

struct adaline
{
    double eta;      /**< learning rate of the algorithm */
    double *weights; /**< weights of the neural network */
    int num_weights; /**< number of weights of the neural network */
};

struct adaline new_adaline(const int num_features, const double eta);
void delete_adaline(struct adaline *ada);
char *adaline_get_weights_str(const struct adaline *ada);
double adaline_fit_sample(struct adaline *ada, const double *x, const int y);
void adaline_fit(struct adaline *ada, double **X, const int *y, const int N);
int adaline_predict(struct adaline *ada, const double *x, double *out);
int adaline_activation(double x);
void test1(double eta);
void test2(double eta);
void test3(double eta);

#endif
