#ifndef DESIGN_H
#define DESIGN_H

#define Z95_CONVERSION_CONSTANT 32
#define ALPHABET_SIZE 95

typedef struct {
    int a;
    int b;
} affine_key_t;

void affine_decrypt(char *s, affine_key_t key);
void affine_encrypt(char *s, affine_key_t key);

#endif
