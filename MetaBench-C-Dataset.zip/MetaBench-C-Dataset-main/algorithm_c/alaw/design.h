#ifndef DESIGN_H
#define DESIGN_H

#include <stddef.h>
#include <stdint.h>

void decode(int16_t *out, uint8_t *in, size_t len);
void encode(uint8_t *out, int16_t *in, size_t len);

#endif
