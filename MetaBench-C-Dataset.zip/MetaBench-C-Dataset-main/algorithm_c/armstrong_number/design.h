#ifndef DESIGN_H
#define DESIGN_H

int isArmstrong(int x);
int order(int x);

#endif
