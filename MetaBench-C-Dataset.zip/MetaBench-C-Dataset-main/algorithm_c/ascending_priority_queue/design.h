#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

struct node {
    int data;
    struct node *next;
};

struct queue {
    struct node *front;
    struct node *rear;
};

extern struct queue q;

void createqueue(void);
void insert(int x);
void show(void);
int removes(void);
void destroyqueue(void);
int empty(void);

#endif
