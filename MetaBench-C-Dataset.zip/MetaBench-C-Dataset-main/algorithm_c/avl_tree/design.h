#ifndef DESIGN_H
#define DESIGN_H

typedef struct avlNode avlNode;

struct avlNode {
    int data;
    int height;
    avlNode *left;
    avlNode *right;
};

avlNode *newNode(int key);
avlNode *findNode(avlNode *root, int data);
avlNode *insert(avlNode *root, int data);
avlNode *delete(avlNode *root, int data);
void printAVL(avlNode *root, int level);
void printPreOrder(avlNode *root);
void printInOrder(avlNode *root);
void printPostOrder(avlNode *root);
avlNode *getMax(avlNode *root);
int nodeHeight(avlNode *node);
avlNode *LeftRightRotate(avlNode *z);
int heightDiff(avlNode *node);
avlNode *RightLeftRotate(avlNode *z);
avlNode *leftRotate(avlNode *z);
avlNode *rightRotate(avlNode *z);
int max(int a, int b);

#endif
