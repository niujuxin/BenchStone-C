#ifndef DESIGN_H
#define DESIGN_H

#include <stddef.h>

#define BEAD(i, j) beads[i * max + j]

void bead_sort(int *a, size_t len);
void display(const int *arr, int n);
int main(int argc, const char *argv[]);

#endif
