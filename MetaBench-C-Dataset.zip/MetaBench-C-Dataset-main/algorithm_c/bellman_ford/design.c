#include "design.h"
#include <stdio.h>

void print(int dist[], int V)
{
    printf("\nVertex  Distance\n");
    for (int i = 0; i < V; i++)
    {
        if (dist[i] != INT_MAX)
            printf("%d\t%d\n", i, dist[i]);
        else
            printf("%d\tINF", i);
    }
}

void BellmanFord(struct Graph *graph, int src)
{
    int V = graph->vertexNum;
    int E = graph->edgeNum;
    int dist[V];

    // Initialize distances array as INF for all except source
    // Intialize source as zero
    for (int i = 0; i < V; i++) dist[i] = INT_MAX;
    dist[src] = 0;

    // Calculate shortest path distance from source to all edges
    // A path can contain maximum (|V|-1) edges
    for (int i = 0; i <= V - 1; i++)
        for (int j = 0; j < E; j++)
        {
            int u = graph->edges[j].src;
            int v = graph->edges[j].dst;
            int w = graph->edges[j].weight;

            if (dist[u] != INT_MAX && dist[u] + w < dist[v])
                dist[v] = dist[u] + w;
        }

    // Iterate inner loop once more to check for negative cycle
    for (int j = 0; j < E; j++)
    {
        int u = graph->edges[j].src;
        int v = graph->edges[j].dst;
        int w = graph->edges[j].weight;

        if (dist[u] != INT_MAX && dist[u] + w < dist[v])
        {
            return;
        }
    }

    print(dist, V);

    return;
}
