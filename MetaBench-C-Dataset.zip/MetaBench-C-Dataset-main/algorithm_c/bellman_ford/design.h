#ifndef DESIGN_H
#define DESIGN_H

#include <limits.h>

struct Edge {
    int src;
    int dst;
    int weight;
};

struct Graph {
    int vertexNum;
    int edgeNum;
    struct Edge *edges;
};

void BellmanFord(struct Graph *graph, int src);
void print(int dist[], int V);

#endif
