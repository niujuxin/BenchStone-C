#ifndef DESIGN_H
#define DESIGN_H

void insertionSort(int *arr, int size);

#endif
