#ifndef DESIGN_H
#define DESIGN_H

int binarysearch1(const int *arr, int l, int r, int x);
int binarysearch2(const int *arr, int l, int r, int x);

#endif
