#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

typedef struct node node;

node *newNode(int data);
node *insert(node *root, int data);
node *delete(node *root, int data);
int find(node *root, int data);
int height(node *root);
void inOrder(node *root);
void purge(node *root);

#endif
