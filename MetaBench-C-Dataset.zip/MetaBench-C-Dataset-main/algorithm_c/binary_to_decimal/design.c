#include "design.h"

int convert_to_decimal(uint64_t number) {
    int decimal_number = 0, i = 0;

    while (number > 0) {
        decimal_number += (number % 10) * pow(2, i);
        number = number / 10;
        i++;
    }

    return decimal_number;
}

double pow(double base, double exponent) {
    double result = 1.0;
    int exp_int = (int)exponent;
    
    if (exponent < 0) {
        base = 1.0 / base;
        exp_int = -exp_int;
    }
    
    for (int i = 0; i < exp_int; i++) {
        result *= base;
    }
    
    return result;
}
