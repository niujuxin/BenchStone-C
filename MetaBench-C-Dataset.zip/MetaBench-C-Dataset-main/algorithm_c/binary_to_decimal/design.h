#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>

int convert_to_decimal(uint64_t number);
double pow(double base, double exponent);

#endif
