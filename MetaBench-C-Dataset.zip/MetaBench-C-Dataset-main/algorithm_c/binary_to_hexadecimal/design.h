#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

int main(void);

#endif
