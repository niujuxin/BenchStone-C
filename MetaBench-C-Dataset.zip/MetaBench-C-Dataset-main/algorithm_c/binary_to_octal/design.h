#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

int three_digits(int n);

#endif
