#ifndef DESIGN_H
#define DESIGN_H

#include <math.h>

#define NMAX 100
#define EPSILON 1e-10

double bisection(double x_left, double x_right, double tolerance);
double func(double x);
double sign(double a, double b);

#endif
