#ifndef DESIGN_H
#define DESIGN_H

#include <stdbool.h>

void sort(int *a, int n);
bool check_sorted(int *a, int n);
void shuffle(int *a, int n);

#endif
