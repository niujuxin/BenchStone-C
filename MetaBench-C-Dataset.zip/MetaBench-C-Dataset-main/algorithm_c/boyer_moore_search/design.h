#ifndef DESIGN_H
#define DESIGN_H

#include <string.h>

#define NUM_OF_CHARS 256

#define max(a, b) (((a) > (b)) ? (a) : (b))

void boyer_moore_search(char *str, char *pattern);
void computeArray(char *pattern, int size, int arr[NUM_OF_CHARS]);

#endif
