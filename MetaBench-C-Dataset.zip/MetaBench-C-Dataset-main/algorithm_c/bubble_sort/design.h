#ifndef DESIGN_H
#define DESIGN_H

#include <stdbool.h>

void swap(int *first, int *second);
void bubbleSort(int *arr, int size);

#endif
