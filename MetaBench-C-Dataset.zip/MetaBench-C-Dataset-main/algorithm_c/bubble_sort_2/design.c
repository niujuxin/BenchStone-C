#include "design.h"

void bubble_sort(int* array_sort)
{
	bool is_sorted = false;

    while (!is_sorted)
    {
		is_sorted = true;

        for (int i = 0; i < MAX - 1; i++)
        {
            if (array_sort[i] > array_sort[i + 1])
            {
                int change_place = array_sort[i];
                array_sort[i] = array_sort[i + 1];
                array_sort[i + 1] = change_place;
                is_sorted = false;
            }
        }
    }
}
