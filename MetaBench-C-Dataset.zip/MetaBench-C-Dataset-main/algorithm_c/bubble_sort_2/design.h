#ifndef DESIGN_H
#define DESIGN_H

#include <stdbool.h>

#define MAX 80

void bubble_sort(int* array_sort);

#endif
