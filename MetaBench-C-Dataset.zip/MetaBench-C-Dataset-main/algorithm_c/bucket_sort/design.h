#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>
#include <assert.h>

#define NARRAY 8
#define NBUCKET 5
#define INTERVAL 10

struct Node
{
    int data;
    struct Node *next;
};

struct Node *InsertionSort(struct Node *list);
int getBucketIndex(int value);
void printBuckets(struct Node *list);
void BucketSort(int arr[]);

#endif
