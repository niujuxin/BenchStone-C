#include "design.h"

int c_atoi(const char *str)
{
    int i;
    int sign;
    long value;
    long prev;

    i = 0;
    sign = 1;
    value = 0;

    /* skipping the spaces */
    while (((str[i] <= 13 && str[i] >= 9) || str[i] == 32) && str[i] != '\0')
        i++;

    /* store the sign if it is negative sign */
    if (str[i] == '-')
	{
        sign = -1;
	i++;
	}
    else if (str[i] == '+')
	{
        sign = 1;
	i++;
	}

    /* converting char by char to a numeric value */
    while (str[i] >= 48 && str[i] <= 57 && str[i] != '\0')
    {
        prev = value;
        value = value * 10 + sign * (str[i] - '0');

        /* managing the overflow */
        if (sign == 1 && prev > value)
            return (-1);
        else if (sign == -1 && prev < value)
            return (0);
        i++;
    }
    return (value);
}
