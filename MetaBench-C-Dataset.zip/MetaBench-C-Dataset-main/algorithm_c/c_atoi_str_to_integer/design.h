#ifndef DESIGN_H
#define DESIGN_H

int c_atoi(const char *str);

#endif
