#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>

typedef struct CantorSet {
    int start;
    int end;
    struct CantorSet *next;
} CantorSet;

void print(CantorSet *head);
void propagate(CantorSet *head);
void free_memory(CantorSet *node);

#endif
