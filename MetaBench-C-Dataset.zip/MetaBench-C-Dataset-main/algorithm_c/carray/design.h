#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct CArray {
    int *array;
    int size;
} CArray;

#define SUCCESS 0
#define ARRAY_FULL 1
#define POSITION_EMPTY 2
#define INVALID_POSITION 3
#define POSITION_INIT 4
#define POSITION_NOT_INIT 5

CArray *valuePositionsCArray(CArray *array, int value);
int bubbleSortCArray(CArray *array);
int pushValueCArray(CArray *array, int value);
int removeValueCArray(CArray *array, int position);
int switchValuesCArray(CArray *array, int position1, int position2);
int selectionSortCArray(CArray *array);
int displayCArray(CArray *array);
int insertionSortCArray(CArray *array);
CArray *getCArray(int size);
CArray *getCopyCArray(CArray *arr);
int valueOcurranceCArray(CArray *array, int value);
int blenderCArray(CArray *array);
int reverseCArray(CArray *array);
int insertValueCArray(CArray *array, int position, int value);
int eraseCArray(CArray *array);
int findMinCArray(CArray *array);
int updateValueCArray(CArray *array, int position, int value);
int findMaxCArray(CArray *array);

void swap(CArray *array, int position1, int position2);

#endif
