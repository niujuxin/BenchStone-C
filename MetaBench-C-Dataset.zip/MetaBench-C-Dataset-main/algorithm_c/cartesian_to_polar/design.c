#include "design.h"

void to_polar(double x, double y, double *r, double *theta)
{
    double thetaFinal = 0.f;

    *r = sqrt(x * x + y * y);

    if (x != 0)
    {
        if (y != 0)
        {
            *theta = atan(y / x);
            if ((x > 0 && y > 0) || (x == -y))
            {  // Q1
                thetaFinal = *theta;
            }
            else if (x < 0 && y > 0)
            {  // Q2
                thetaFinal = *theta + M_PI;
            }
            else if (x < 0 && y < 0)
            {  // Q3
                thetaFinal = *theta - M_PI;
            }
            else if (x > 0 && y < 0)
            {  // Q4
                thetaFinal = 2 * M_PI - *theta;
            }
            else
            {
                /* Should not reach here */
            }
        }
    }
    else
    {  // exceptions when no actual angle is present
        if (y > 0)
        {
            thetaFinal = M_PI / 2;
        }
        else
        {
            thetaFinal = -(M_PI / 2);
        }
    }
    if (y == 0)
    {
        if (x > 0)
        {
            thetaFinal = 0;
        }
        else
        {
            thetaFinal = -M_PI;
        }
    }

    *theta = thetaFinal;
}
