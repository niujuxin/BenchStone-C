#ifndef DESIGN_H
#define DESIGN_H

#include <math.h>

void to_polar(double x, double y, double *r, double *theta);

#endif
