#ifndef DESIGN_H
#define DESIGN_H

long int factorial(int n);

#endif
