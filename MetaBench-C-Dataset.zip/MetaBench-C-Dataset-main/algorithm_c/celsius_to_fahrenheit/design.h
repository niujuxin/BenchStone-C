#ifndef DESIGN_H
#define DESIGN_H

double celcius_to_fahrenheit(double celsius);

#endif
