#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>

struct node
{
  int data;
  struct node *next;
};

struct node *first;
struct node *last;

void create(void);
void deletenode(int k);
void traverse(void);

#endif
