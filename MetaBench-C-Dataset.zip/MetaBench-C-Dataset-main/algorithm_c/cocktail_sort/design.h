#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0

void cocktailSort(int arr[], int size);

#endif
