#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>

void display(int *numbers, int size);
void sort(int *numbers, int size);

#endif
