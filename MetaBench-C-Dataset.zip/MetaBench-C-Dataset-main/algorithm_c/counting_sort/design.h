#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void);

#endif
