#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>

void display(int *arr, int n);
void cycleSort(int *arr, int n);
void swap(int *a, int *b);

#endif
