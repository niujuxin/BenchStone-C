#include "design.h"
#include <stdlib.h>
#include <string.h>

bool isbad_alphabet(const char* alphabet) {
	uint64_t len = strlen(alphabet);
	
	/* Checking th lenght */	
	if (len < 2) {
		return true;
	}
	/* Browse the alphabet */
	for (int i = 0; i < len ; i++) {
		/* Searching for duplicates */ 
		if (strchr(alphabet + i + 1, alphabet[i]))
			return true;
	}
	return false;
}

uint64_t converted_len(uint64_t nb, short base) {
	/* Counting the number of characters translated to the base*/
	if (nb > base - 1) {
		return (converted_len(nb/base, base) + 1);
	}
	return 1;
}

void convertion(uint64_t nb, const char* alphabet, short base, char* converted) {
	/* Recursive convertion */
	*(converted) = *(alphabet + nb%base);
	if (nb > base - 1) {
		convertion(nb/base, alphabet, base, --converted);
	}
}

char* decimal_to_anybase(uint64_t nb, const char* alphabet) {
	char* converted;

	/* Verify that alphabet is valid */
	if (isbad_alphabet(alphabet)) {
		return NULL;
	}
	/* Convertion */
	uint64_t base = strlen(alphabet);
	uint64_t final_len = converted_len(nb, base);
	converted = malloc(sizeof(char) * (final_len + 1));
	converted[final_len] = 0;
	convertion(nb, alphabet, base, converted + final_len - 1);
	return converted;
}
