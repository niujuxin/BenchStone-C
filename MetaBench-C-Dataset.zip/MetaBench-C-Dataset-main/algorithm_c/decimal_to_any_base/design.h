#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>
#include <stdbool.h>

char* decimal_to_anybase(uint64_t nb, const char* alphabet);
bool isbad_alphabet(const char* alphabet);
uint64_t converted_len(uint64_t nb, short base);
void convertion(uint64_t nb, const char* alphabet, short base, char* converted);

#endif
