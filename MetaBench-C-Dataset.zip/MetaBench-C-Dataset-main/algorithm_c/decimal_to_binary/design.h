#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

#define MAXBITS 32

int main(void);

#endif /* DESIGN_H */
