#ifndef DESIGN_H
#define DESIGN_H

int decimal_to_binary(unsigned int number);

#endif
