#ifndef DESIGN_H
#define DESIGN_H

void decimal2Hexadecimal(long num);

#endif
