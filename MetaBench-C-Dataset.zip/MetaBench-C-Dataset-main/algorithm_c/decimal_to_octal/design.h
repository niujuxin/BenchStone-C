#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

void decimal2Octal(long decimalnum);

#endif
