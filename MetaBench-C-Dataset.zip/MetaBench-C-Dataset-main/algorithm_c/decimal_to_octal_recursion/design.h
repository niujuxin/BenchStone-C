#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

int decimal_to_octal(int decimalNumber);

#endif
