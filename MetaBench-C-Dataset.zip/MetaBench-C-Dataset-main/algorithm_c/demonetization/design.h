#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>

int ways(int n, int *coin, int m);

#endif
