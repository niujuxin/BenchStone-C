#include "design.h"

int visited[MAX_NODES];

bool adjacent(Graph g, Vertex v, Vertex w)
{
    return (g->edges[v][w] != 0);
}

bool dfsPathCheck(Graph g, int nV, Vertex v, Vertex dest)
{
    Vertex w;
    for (w = 0; w < nV; w++)
        if (adjacent(g, v, w) && visited[w] == -1)
        {
            visited[w] = v;
            if (w == dest)
                return true;
            else if (dfsPathCheck(g, nV, w, dest))
                return true;
        }
    return false;
}

bool findPathDFS(Graph g, int nV, Vertex src, Vertex dest)
{
    Vertex v;
    for (v = 0; v < nV; v++) visited[v] = -1;
    visited[src] = src;
    return dfsPathCheck(g, nV, src, dest);
}
