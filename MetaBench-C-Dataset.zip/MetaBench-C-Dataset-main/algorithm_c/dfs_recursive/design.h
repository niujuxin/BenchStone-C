#ifndef DESIGN_H
#define DESIGN_H

#include <stdbool.h>

typedef int Vertex;
typedef struct GraphRep *Graph;

struct GraphRep
{
    int **edges;  // adjacency matrix
    int nV;       // #vertices
    int nE;       // #edges
};

bool findPathDFS(Graph g, int nV, Vertex src, Vertex dest);
bool dfsPathCheck(Graph g, int nV, Vertex v, Vertex dest);
bool adjacent(Graph g, Vertex v, Vertex w);

#define MAX_NODES 1000
extern int visited[MAX_NODES];

#endif
