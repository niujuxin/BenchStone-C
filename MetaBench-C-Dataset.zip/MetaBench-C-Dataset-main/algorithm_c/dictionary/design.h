#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

#define MAXELEMENTS 1000

typedef struct Dictionary {
    int number_of_elements;
    void *elements[MAXELEMENTS];
} Dictionary;

int add_item_index(Dictionary *dic, int index, void *item);
int add_item_label(Dictionary *dic, char label[], void *item);
Dictionary *create_dict(void);
void *get_element_label(Dictionary *dict, char s[]);
void *get_element_index(Dictionary *dict, int index);
int get_hash(char s[]);

#endif
