#include "design.h"
#include <stdlib.h>

int V;
int mat[100][100];
int dist[100];
int visited[100];
int vp;
int qp = 0;
int q[100];

void dijkstra(int s)
{
    dist[s] = 0;
    int i;
    for (i = 0; i < V; ++i)
    {
        if (i != s)
        {
            dist[i] = INF;
        }
        enqueue(i);
    }
    while (queue_has_something())
    {
        int u = dequeue();
        visited[vp++] = u;
        for (i = 0; i < V; ++i)
        {
            if (mat[u][i])
            {
                if (dist[i] > dist[u] + mat[u][i])
                {
                    dist[i] = dist[u] + mat[u][i];
                }
            }
        }
    }
}

void enqueue(int v) { q[qp++] = v; }

int dequeue()
{
    qsort(q, qp, sizeof(int), cf);
    return q[--qp];
}

int queue_has_something() { return (qp > 0); }

int cf(void *a, void *b)
{
    int *x = (int *)a;
    int *y = (int *)b;
    return *y - *x;
}

int main(int argc, char const *argv[])
{
    int i, j;
    (void)argc;
    (void)argv;
    
    V = 0;
    
    for (i = 0; i < V; ++i)
    {
        for (j = 0; j < V; ++j)
        {
            mat[i][j] = 0;
        }
    }

    dijkstra(0);

    return 0;
}
