#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

#define INF 999999

extern int V;
extern int mat[100][100];
extern int dist[100];
extern int visited[100];
extern int vp;
extern int qp;
extern int q[100];

void dijkstra(int s);
void enqueue(int i);
int dequeue(void);
int queue_has_something(void);
int cf(void *a, void *b);

#endif
