#ifndef DESIGN_H
#define DESIGN_H

#define NULL ((void *)0)

typedef struct list
{
    double value;
    struct list *next, *prev;
} List;

List *create(double node_value);
List *insert(List *my_list, double node_value, int position);
void print(List *my_list);
int search(List *my_list, double value);
List *delete(List *my_list, int position);

void example(void);

#endif
