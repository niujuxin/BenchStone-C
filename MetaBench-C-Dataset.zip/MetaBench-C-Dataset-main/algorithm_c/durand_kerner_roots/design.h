#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <time.h>
#include <limits.h>

#define ACCURACY 1e-10

int check_termination(double tol_condition);
long double complex poly_function(long double *coeffs, unsigned int degree, long double complex x);
char *complex_str(long double complex x);

#endif
