#include "design.h"

int show_capacity(DArrayStack *ptr) { return ptr->capacity; }

int stack_size(DArrayStack *ptr) { return ptr->top + 1; }

DArrayStack *create_stack(int cap)
{
    DArrayStack *ptr;
    ptr = (DArrayStack *)malloc(sizeof(DArrayStack));
    ptr->capacity = cap;
    ptr->top = -1;
    ptr->arrPtr = (int *)malloc(sizeof(int) * cap);
    return (ptr);
}

int isempty(DArrayStack *ptr)
{
    if (ptr->top == -1)
    {
        return 1;
    }
    return 0;
}
