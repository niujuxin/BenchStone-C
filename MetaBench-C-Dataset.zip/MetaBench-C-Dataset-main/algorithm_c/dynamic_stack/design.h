#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

typedef struct {
    int *arrPtr;
    int top;
    int capacity;
} DArrayStack;

int show_capacity(DArrayStack *ptr);
int stack_size(DArrayStack *ptr);
DArrayStack *create_stack(int cap);
int isempty(DArrayStack *ptr);

#endif
