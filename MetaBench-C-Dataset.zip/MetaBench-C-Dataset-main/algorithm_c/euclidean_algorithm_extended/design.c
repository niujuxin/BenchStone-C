#include "design.h"

static inline void xy_push(int arr[2], int newval)
{
    arr[1] = arr[0];
    arr[0] = newval;
}

static inline void calculate_next_xy(int quotient, int prev[2])
{
    int next = prev[1] - (prev[0] * quotient);
    xy_push(prev, next);
}

euclidean_result_t extended_euclidean_algorithm(int a, int b)
{
    int previous_remainder = 1;
    int previous_x_values[2] = {0, 1};
    int previous_y_values[2] = {1, 0};
    div_t div_result;
    euclidean_result_t result;

    /* swap values of a and b */
    if (abs(a) < abs(b))
    {
        a ^= b;
        b ^= a;
        a ^= b;
    }

    div_result.rem = b;

    while (div_result.rem > 0)
    {
        div_result = div(a, b);

        previous_remainder = b;

        a = b;
        b = div_result.rem;

        calculate_next_xy(div_result.quot, previous_x_values);
        calculate_next_xy(div_result.quot, previous_y_values);
    }

    result.gcd = previous_remainder;
    result.x = previous_x_values[1];
    result.y = previous_y_values[1];

    return result;
}
