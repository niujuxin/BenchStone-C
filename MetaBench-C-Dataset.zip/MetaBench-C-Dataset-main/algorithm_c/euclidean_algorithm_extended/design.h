#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

typedef struct {
    int gcd;
    int x;
    int y;
} euclidean_result_t;

euclidean_result_t extended_euclidean_algorithm(int a, int b);

#endif
