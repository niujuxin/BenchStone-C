#include "design.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

bool validV(Graph g, Vertex v) { return (g != NULL && v >= 0 && v < g->nV); }

bool adjacent(Graph g, Vertex v, Vertex w)
{
    assert(g != NULL && validV(g, v) && validV(g, w));

    return (g->edges[v][w] != 0);
}

Graph newGraph(int V)
{
    assert(V >= 0);
    int i;

    Graph g = malloc(sizeof(GraphRep));
    assert(g != NULL);
    g->nV = V;
    g->nE = 0;

    // allocate memory for each row
    g->edges = malloc(V * sizeof(int *));
    assert(g->edges != NULL);
    // allocate memory for each column and initialise with 0
    for (i = 0; i < V; i++)
    {
        g->edges[i] = calloc(V, sizeof(int));
        assert(g->edges[i] != NULL);
    }

    return g;
}

void freeGraph(Graph g)
{
    assert(g != NULL);

    int i;
    for (i = 0; i < g->nV; i++) free(g->edges[i]);
    free(g->edges);
    free(g);
}

void insertEdge(Graph g, Edge e)
{
    assert(g != NULL && validV(g, e.v) && validV(g, e.w));

    if (!g->edges[e.v][e.w])
    {  // edge e not in graph
        g->edges[e.v][e.w] = 1;
        g->edges[e.w][e.v] = 1;
        g->nE++;
    }
}

int degree(Graph g, int nV, Vertex v)
{
    int deg = 0;
    Vertex w;
    for (w = 0; w < nV; w++)
        if (adjacent(g, v, w))
            deg++;
    return deg;
}

bool hasEulerPath(Graph g, int nV, Vertex v, Vertex w)
{
    if (v != w)
    {
        if (degree(g, nV, v) % 2 == 0 || degree(g, nV, w) % 2 == 0)
            return false;
    }
    else if (degree(g, nV, v) % 2 != 0)
    {
        return false;
    }
    Vertex x;
    for (x = 0; x < nV; x++)
        if (x != v && x != w && degree(g, nV, x) % 2 != 0)
            return false;
    return true;
}

int main(void)
{
    Edge e;
    int n;

    scanf("%d", &n);
    Graph g = newGraph(n);

    Vertex src, dest;
    scanf("%d", &src);
    scanf("%d", &dest);

    while (scanf("%d", &e.v) == 1)
    {
        scanf("%d", &e.w);
        insertEdge(g, e);
    }

    if (hasEulerPath(g, n, src, dest))
        ;
    else
        ;

    freeGraph(g);
    return 0;
}
