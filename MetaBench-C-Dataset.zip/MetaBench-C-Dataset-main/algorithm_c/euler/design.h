#ifndef DESIGN_H
#define DESIGN_H

#include <stdbool.h>

typedef int Vertex;

typedef struct GraphRep {
    int **edges;
    int nV;
    int nE;
} GraphRep;

typedef struct GraphRep *Graph;

typedef struct edge {
    Vertex v;
    Vertex w;
} Edge;

int degree(Graph g, int nV, Vertex v);
Graph newGraph(int n);
void insertEdge(Graph g, Edge e);
void freeGraph(Graph g);
bool hasEulerPath(Graph g, int nV, Vertex v, Vertex w);
bool adjacent(Graph g, Vertex v, Vertex w);
bool validV(Graph g, Vertex v);

#endif
