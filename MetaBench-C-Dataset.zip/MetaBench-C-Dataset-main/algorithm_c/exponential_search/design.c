#include "design.h"

int64_t binary_search(const int64_t* arr, const uint16_t l_index, const uint16_t r_index, const int64_t n) 
{
    // calculate the middle index of the array
    uint16_t middle_index = l_index + ( r_index - l_index ) / 2;
    // base cases
    if ( l_index > r_index ) { return -1; }
    if ( arr[middle_index] == n ) { return middle_index; }
    // recursion
    if ( arr[middle_index] > n ) { return binary_search(arr, l_index, middle_index-1, n); } // left
    return binary_search(arr, middle_index+1, r_index, n); // right
}

int64_t exponential_search(const int64_t* arr, const uint16_t length, const int64_t n) 
{
    if ( length == 0 ) { return -1; }
    // find the upperbound
    uint32_t upper_bound = 1;
    while ( upper_bound <= length && arr[upper_bound] < n ) { upper_bound = upper_bound * 2; }
    // calculate the range ( between lower_boud and upper_bound )
    uint16_t lower_bound = upper_bound/2;
    if ( upper_bound > length ) { upper_bound = length; }
    // apply the binary search in the range
    return binary_search(arr, lower_bound, upper_bound, n);
}
