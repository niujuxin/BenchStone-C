#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>

int64_t binary_search(const int64_t* arr, const uint16_t l_index, const uint16_t r_index, const int64_t n);
int64_t exponential_search(const int64_t* arr, const uint16_t length, const int64_t n);

#endif
