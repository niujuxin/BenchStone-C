#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct _large_num
{
    char *digits;            /**< array to store individual digits */
    unsigned int num_digits; /**< number of digits in the number */
} large_num;

large_num *new_number(void);
void multiply(large_num *num, int multiplier);
void delete_number(large_num *num);
void add_digit(large_num *num, unsigned int value);

#endif
