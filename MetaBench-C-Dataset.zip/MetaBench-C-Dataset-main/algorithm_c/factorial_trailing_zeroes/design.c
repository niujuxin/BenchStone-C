#include "design.h"

double pow(double x, double y)
{
    double result = 1.0;
    int i;
    int exp;
    
    if (y == 0.0)
        return 1.0;
    
    if (y < 0.0)
    {
        x = 1.0 / x;
        y = -y;
    }
    
    exp = (int)y;
    
    for (i = 0; i < exp; i++)
    {
        result *= x;
    }
    
    return result;
}

int main()
{
    int i, n, test = 0, count = 0;
    // taking input number n
    scanf("%d", &n);

    // looping from 1 till loop break
    for (i = 1;; i++)
    {
        test =
            n /
            pow(5,
                i);  // division of n by ith power of 5(storing in integer form)
        if (test !=
            0)  // condition for zeroes at end corresponding individual ith case
        {
            count = count + test;
        }
        else
            break;  // break the loop for if test=0
    }
    printf("%d\n", count);
    return 0;
}
