#include "design.h"
#include <stdlib.h>
#include <string.h>

unsigned int fib(int number)
{
    // Check for negative integers
    if (number <= 0)
    {
        exit(EXIT_FAILURE);
    }

    // Base conditions
    if (number == 1)
        return 0;

    if (number == 2)
        return 1;

    // Recursive call to the function
    return fib(number - 1) + fib(number - 2);
}

int getInput(void)
{
    int num, excess_len;
    char buffer[3], *endPtr;

    while (1)
    {  // Repeat until a valid number is entered
        printf("Please enter a valid number:");
        fgets(buffer, 3, stdin);  // Inputs the value from user

        excess_len = 0;
        if (!(buffer[0] == '\n' ||
            buffer[1] == '\n' ||
            buffer[2] == '\n')) {
            while (getchar() != '\n') excess_len++;
        }

        num = strtol(buffer, &endPtr,
                     10);  // Attempts to convert the string to integer

        // Checking the input
        if (  // The number is too large
            (excess_len > 0 || num > 48) ||
            // Characters other than digits are included in the input
            (*endPtr != '\0' && *endPtr != '\n') ||
            // No characters are entered
            endPtr == buffer)
        {
            continue;
        }

        break;
    }

    printf("\nEntered digit: %d (it might take sometime)\n", num);
    return num;
}

void test(void)
{
    const int sets[][2] = {
        {0, 0}, {1, 1}, {2, 10}, {3, 11}, {4, 100}, {6, 110}, {7, 111},
    };

    for (int i = 0, size = sizeof(sets) / sizeof(sets[0]); i < size; ++i)
    {
    }
}

int main()
{
    // Performing the test
    test();
    printf("Tests passed...\n");

    // Getting n
    printf(
        "Enter n to find nth fibonacci element...\n"
        "Note: You would be asked to enter input until valid number ( less "
        "than or equal to 48 ) is entered.\n");

    int number = getInput();
    clock_t start, end;

    start = clock();
    printf("Fibonacci element %d is %u ", number, fib(number));
    end = clock();

    printf("in %.3f seconds.\n", ((double)(end - start)) / CLOCKS_PER_SEC );
    return 0;
}
