#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <time.h>

void test(void);
int getInput(void);
unsigned int fib(int number);

#endif
