#include "design.h"

int fib(int N)
{
    if (N == 0)
        return 0;
    if (N == 1)
        return 1;
    return fib(N - 1) + fib(N - 2);
}

int main(int argc, char *argv[])
{
    int number;

    // Asks for the number/position of term in Fibonnacci sequence
    if (argc == 2)
        number = atoi(argv[1]);
    else
    {
        printf("Enter the value of n(n starts from 0 ): ");
        scanf("%d", &number);
    }

    printf("The nth term is : %d \n", fib(number));

    return 0;
}
