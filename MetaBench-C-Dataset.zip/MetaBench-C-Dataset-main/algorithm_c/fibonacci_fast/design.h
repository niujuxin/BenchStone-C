#ifndef DESIGN_H
#define DESIGN_H

#include <locale.h>
#include <stdio.h>
#include <stdlib.h>

int fib(unsigned long n, unsigned long *result, void *unused);

#endif
