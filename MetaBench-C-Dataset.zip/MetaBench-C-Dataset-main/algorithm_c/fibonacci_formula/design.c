#include "design.h"
#include <stdio.h>
#include <assert.h>

int fib(int N)
{
    if (N == 0)
        return 0;
    if (N == 1)
        return 1;
    return fib(N - 1) + fib(N - 2);
}

static void test()
{
    assert(fib(5) == 5);
    assert(fib(2) == 1);
    assert(fib(9) == 34);
}

int main() {
    test();

    for(int i = 0; i <= 10; i++){
        printf("%d. fibonacci number is: %d\n", i, fib(i));
    }
    return 0;
}
