#ifndef DESIGN_H
#define DESIGN_H

int fib(int N);
static void test();

#endif
