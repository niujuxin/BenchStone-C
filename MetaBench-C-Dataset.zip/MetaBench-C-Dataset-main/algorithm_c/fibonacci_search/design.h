#ifndef DESIGN_H
#define DESIGN_H

int fibMonaccianSearch(int arr[], int x, int n);

#endif
