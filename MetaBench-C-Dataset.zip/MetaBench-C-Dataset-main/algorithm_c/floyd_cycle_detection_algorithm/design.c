#include "design.h"

uint32_t duplicateNumber(const uint32_t *in_arr, size_t n)
{
    if (n <= 1) {
        return -1;
    }
    uint32_t tortoise = in_arr[0];
    uint32_t hare = in_arr[0];
    do {
        tortoise = in_arr[tortoise];
        hare = in_arr[in_arr[hare]];
    } while (tortoise != hare);
    tortoise = in_arr[0];
    while (tortoise != hare) {
        tortoise = in_arr[tortoise];
        hare = in_arr[hare];
    }
    return tortoise;
}
