#ifndef DESIGN_H
#define DESIGN_H

#include <stddef.h>
#include <stdint.h>

uint32_t duplicateNumber(const uint32_t *in_arr, size_t n);

#endif
