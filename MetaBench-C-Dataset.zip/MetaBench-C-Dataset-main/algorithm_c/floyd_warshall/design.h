#ifndef DESIGN_H
#define DESIGN_H

#include <limits.h>

struct Graph {
    int vertexNum;
    int **edges;
};

void FloydWarshall(struct Graph *graph);

#endif
