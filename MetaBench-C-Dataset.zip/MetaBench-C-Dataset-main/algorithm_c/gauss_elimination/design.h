#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <math.h>

#define ARRAY_SIZE 10

void display(float m[ARRAY_SIZE][ARRAY_SIZE], int n);
float interchange(float m[ARRAY_SIZE][ARRAY_SIZE], int i, int n);
float eliminate(float m[ARRAY_SIZE][ARRAY_SIZE], int i, int n);

#endif
