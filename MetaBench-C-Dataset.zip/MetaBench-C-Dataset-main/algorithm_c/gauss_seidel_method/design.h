#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <math.h>

int main(void);

#endif
