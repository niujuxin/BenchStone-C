#include "design.h"

int hamming_distance(char* str1, char* str2)
{
    int i = 0, distance = 0;

    while (str1[i] != '\0')
    {
        if (str1[i] != str2[i])
        {
            distance++;
        }
        i++;
    }

    return distance;
}
