#ifndef DESIGN_H
#define DESIGN_H

int hamming_distance(char* str1, char* str2);

#endif
