#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>

uint32_t adler32(const char* s);
void test_adler32();

#endif /* DESIGN_H */
