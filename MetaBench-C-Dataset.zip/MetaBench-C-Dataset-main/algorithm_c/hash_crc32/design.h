#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>

uint32_t crc32(const char* s);

#endif
