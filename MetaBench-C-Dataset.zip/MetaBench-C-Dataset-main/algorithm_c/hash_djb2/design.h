#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>
#include <stddef.h>

uint64_t djb2(const char* s);

#endif /* DESIGN_H */
