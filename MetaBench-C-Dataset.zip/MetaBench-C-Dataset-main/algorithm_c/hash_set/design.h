#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

#define DEFAULT_HASH_SET_CAPACITY 16

typedef struct {
    void **keys;
    void **values;
    size_t length;
    size_t capacity;
} hash_set_t;

extern hash_set_t *init_hash_set();

#endif
