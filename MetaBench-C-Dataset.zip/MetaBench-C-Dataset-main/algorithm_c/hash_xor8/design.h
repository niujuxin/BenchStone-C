#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>
#include <stddef.h>

uint8_t xor8(const char* s);

#endif
