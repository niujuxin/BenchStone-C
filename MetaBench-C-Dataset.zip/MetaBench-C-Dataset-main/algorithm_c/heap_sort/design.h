#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

void max_heapify(int *a, int i, int n);
void build_maxheap(int *a, int n);
void heapsort(int *a, int n);

#endif
