#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>

void swap(int8_t *first, int8_t *second);
void heapSort(int8_t *arr, const uint8_t size);

#endif
