#include "design.h"
#include <string.h>
#include <stdlib.h>

const char *hello(void)
{
    char *ans = strdup("Hello, World!");
    /* string is pointer of the first character */
    return ans;
}
