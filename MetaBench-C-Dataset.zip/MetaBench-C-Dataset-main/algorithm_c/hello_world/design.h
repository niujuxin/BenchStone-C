#ifndef DESIGN_H
#define DESIGN_H

const char *hello(void);

#endif
