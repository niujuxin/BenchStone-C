#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <string.h>

const char *hex_to_oct(const char *hex);

#endif /* DESIGN_H */
