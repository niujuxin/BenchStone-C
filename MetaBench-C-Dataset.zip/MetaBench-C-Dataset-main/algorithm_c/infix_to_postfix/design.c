#include "design.h"

char* convert(char* in, uint16_t numRows)
{
    uint16_t len = strlen(in);

    if (len < numRows)
    {
        numRows = len;
    }
    char* out = calloc(len + 1, sizeof(char));

    if (numRows < 2)
    {
        memcpy(out, in, len + 1);
        return out;
    }

    uint16_t max = numRows - 1;
    uint16_t rr = 2 * max;
    uint16_t i = 0;
    uint16_t o = 0;
    uint16_t delta = 0;

    // first row
    while (i < len)
    {
        out[o++] = in[i];
        i += rr;
    }

    // middle rows
    for (uint16_t l = 1; l < max; l++)
    {
        i = l;
        delta = 2 * l;
        while (i < len)
        {
            out[o++] = in[i];
            delta = rr - delta;
            i += delta;
        }
    }

    // last row
    i = max;
    while (i < len)
    {
        out[o++] = in[i];
        i += rr;
    }

    return out;
}
