#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>
#include <string.h>
#include <stdlib.h>

char* convert(char* in, uint16_t numRows);

#endif
