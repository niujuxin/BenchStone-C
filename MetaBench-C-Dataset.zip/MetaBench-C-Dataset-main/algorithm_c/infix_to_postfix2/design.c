#include "design.h"

int main() {
	return 0;
}
