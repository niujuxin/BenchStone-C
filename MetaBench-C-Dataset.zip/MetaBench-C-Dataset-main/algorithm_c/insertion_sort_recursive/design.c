#include "design.h"

void RecursionInsertionSort(int *arr, int size)
{
    if(size <= 0)
    {
        return;
    }
    
    // marking recursive call to reach starting element
    RecursionInsertionSort(arr,size-1);
    
    int key = arr[size-1];
    int j = size-2;
    // swapping logic for insertion sort
    while(j >= 0 && arr[j] > key)
    {
        arr[j+1] = arr[j];
        j--;
    }
    arr[j+1] = key;
}
