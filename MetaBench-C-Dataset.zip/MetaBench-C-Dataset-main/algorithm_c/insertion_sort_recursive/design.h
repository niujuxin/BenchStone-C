#ifndef DESIGN_H
#define DESIGN_H

void RecursionInsertionSort(int *arr, int size);

#endif
