#include "design.h"

char *int_to_string(uint16_t value, char *dest, int base)
{
    const char hex_table[] = {'0', '1', '2', '3', '4', '5', '6', '7',
                              '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    int len = 0;
    do
    {
        dest[len++] = hex_table[value % base];
        value /= base;
    } while (value != 0);

    /* reverse characters */
    for (int i = 0, limit = len / 2; i < limit; ++i)
    {
        char t = dest[i];
        dest[i] = dest[len - 1 - i];
        dest[len - 1 - i] = t;
    }
    dest[len] = '\0';
    return dest;
}
