#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>

char *int_to_string(uint16_t value, char *dest, int base);

#endif
