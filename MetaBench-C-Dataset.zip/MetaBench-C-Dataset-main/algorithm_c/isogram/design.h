#ifndef DESIGN_H
#define DESIGN_H

#include <stdbool.h>

bool is_isogram(const char phrase[]);

#endif
