#ifndef DESIGN_H
#define DESIGN_H

#include <stddef.h>

#define min(a, b) (((a) < (b)) ? (a) : (b))

int jump_search(const int *arr, int x, size_t n);

#endif
