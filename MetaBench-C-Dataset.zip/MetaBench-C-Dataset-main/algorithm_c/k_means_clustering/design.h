#ifndef DESIGN_H
#define DESIGN_H

#include <stddef.h>

typedef struct observation {
    double x;
    double y;
    int group;
} observation;

typedef struct cluster {
    double x;
    double y;
    size_t count;
} cluster;

cluster* kMeans(observation observations[], size_t size, int k);

#endif
