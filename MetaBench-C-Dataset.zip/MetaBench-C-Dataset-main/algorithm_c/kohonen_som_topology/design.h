#ifndef DESIGN_H
#define DESIGN_H

#include <time.h>

double get_clock_diff(clock_t start_clk, clock_t end_clk);
void test1(void);
void test2(void);
void test3(void);
int save_nd_data(const char *fname, double **X, int num_points, int num_features);
void kohonen_som_tracer(double **X, double *const *W, int num_samples, int num_features, int num_out, double alpha_min);
void test_3d_classes(double *const *data, int N);
void kohonen_update_weights(double const *x, double *const *W, double *D, int num_out, int num_features, double alpha, int R);
void kohonen_get_min_1d(double const *X, int N, double *val, int *idx);
double _random(double a, double b);
void test_circle(double **X, int N);
void test_lamniscate(double **X, int N);

#ifndef max
#define max(a,b) ((a) > (b) ? (a) : (b))
#endif

#ifndef min
#define min(a,b) ((a) < (b) ? (a) : (b))
#endif

#endif
