#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

struct Edge {
    int src, dest, weight;
};

struct Graph {
    int V, E;
    struct Edge *edge;
};

struct subset {
    int parent;
    int rank;
};

void KruskalMST(struct Graph *graph);
void Union(struct subset subsets[], int x, int y);
int myComp(const void *a, const void *b);
int find(struct subset subsets[], int i);

#endif
