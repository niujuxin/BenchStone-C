#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

int gcd(int a, int b);
int lcm(int a, int b);

#endif
