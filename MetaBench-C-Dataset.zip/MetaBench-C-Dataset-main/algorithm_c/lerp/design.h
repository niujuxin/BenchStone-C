#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

float lerp(float k0, float k1, float t);

#endif
