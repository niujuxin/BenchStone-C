#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void PrintSortedPermutations(char *str);

int compare(const void *a, const void *b);
void swap(char *a, char *b);

#endif
