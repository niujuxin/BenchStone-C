#include "design.h"

L List_push(L list, void *val)
{
    L new_elem = (L)malloc(sizeof(struct L_struct));
    new_elem->val = val;
    new_elem->next = list;
    return new_elem;
}

void **List_toArray(L list)
{
    int i, n = List_length(list) + 1;
    void **array = (void **)malloc((n + 1) * sizeof(*array));

    for (i = 0; i < n; i++)
    {
        array[i] = list->val;
        list = list->next;
    }
    array[i] = NULL;
    return array;
}

int List_length(L list)
{
    int n;
    for (n = 0; list; list = list->next) n++;
    return n - 1;
}

L List_append(L list, L tail)
{
    L *p = &list;
    while ((*p)->next)
    {
        p = &(*p)->next;
    }

    *p = tail;
    return list;
}

L List_list(L list, void *val, ...)
{
    va_list ap;
    L *p = &list;

    va_start(ap, val);
    for (; val; val = va_arg(ap, void *))
    {
        *p = malloc(sizeof(struct L_struct));
        (*p)->val = val;
        p = &(*p)->next;
    }
    *p = NULL;
    va_end(ap);
    return list;
}

L List_init(void)
{
    L list;
    list = (L)malloc(sizeof(struct L_struct));
    list->next = NULL;
    return list;
}
