#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>
#include <stdarg.h>

typedef struct L_struct *L;

struct L_struct {
    void *val;
    L next;
};

L List_push(L list, void *val);
void **List_toArray(L list);
int List_length(L list);
L List_append(L list, L tail);
L List_list(L list, void *val, ...);
L List_init(void);

#endif
