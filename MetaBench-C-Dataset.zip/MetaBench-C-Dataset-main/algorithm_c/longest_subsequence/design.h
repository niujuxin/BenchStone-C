#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

void longestSub(int *ARRAY, int ARRAY_LENGTH, int **RESULT, int *RESULT_LENGTH);

#endif
