#ifndef DESIGN_H
#define DESIGN_H

int lu_decomposition(double **A, double **L, double **U, int mat_size);

#endif
