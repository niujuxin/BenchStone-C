#include "design.h"

int matrixChainOrder(int l, const int *p, int *s)
{
    // mat stores the cost for a chain that starts at i and ends on j (inclusive
    // on both ends)
    int **mat = malloc(l * sizeof(int *));
    for (int i = 0; i < l; ++i)
    {
        mat[i] = malloc(l * sizeof(int));
    }

    for (int i = 0; i < l; ++i)
    {
        mat[i][i] = 0;
    }
    // cl denotes the difference between start / end indices, cl + 1 would be
    // chain length.
    for (int cl = 1; cl < l; ++cl)
    {
        for (int i = 0; i < l - cl; ++i)
        {
            int j = i + cl;
            mat[i][j] = INT_MAX;
            for (int div = i; div < j; ++div)
            {
                int q = mat[i][div] + mat[div + 1][j] + p[i] * p[div] * p[j];
                if (q < mat[i][j])
                {
                    mat[i][j] = q;
                    s[i * l + j] = div;
                }
            }
        }
    }
    int result = mat[0][l - 1];

    // Free dynamically allocated memory
    for (int i = 0; i < l; ++i)
    {
        free(mat[i]);
    }
    free(mat);

    return result;
}
