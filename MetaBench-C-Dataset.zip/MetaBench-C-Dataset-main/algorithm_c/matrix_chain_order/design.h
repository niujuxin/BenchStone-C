#ifndef DESIGN_H
#define DESIGN_H

#include <limits.h>
#include <stdlib.h>

int matrixChainOrder(int l, const int *p, int *s);

#endif
