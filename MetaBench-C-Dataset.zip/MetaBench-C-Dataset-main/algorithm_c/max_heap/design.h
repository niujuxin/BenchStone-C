#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

typedef struct {
    int size;
    int *p;
    int count;
} Heap;

Heap *create_heap(Heap *heap);

#endif
