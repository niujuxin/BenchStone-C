#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

struct NFAState {
    int ruleCount;
    struct transRule** rules;
};

struct transRule {
    struct NFAState* target;
    char cond;
};

struct NFA {
    int stateCount;
    struct NFAState** statePool;
    int ruleCount;
    struct transRule** rulePool;
    int CSCount;
    struct NFAState** currentStates;
    int subCount;
    struct NFA** subs;
    int wrapperFlag;
};

struct ASTNode {
    char content;
    struct ASTNode* left;
    struct ASTNode* right;
};

struct NFA* compileFromAST(struct ASTNode* root);
void redirect(struct NFA* nfa, struct NFAState* src, struct NFAState* dest);
struct transRule* createRule(struct NFAState* state, char c);
struct NFA* createNFA(void);
void addRule(struct NFA* nfa, struct transRule* rule, int loc);
int isLiteral(const char ch);
void destroyNFA(struct NFA* nfa);
void destroyState(struct NFAState* state);
struct NFAState* createState(void);
void addState(struct NFA* nfa, struct NFAState* state);
void destroyRule(struct transRule* rule);

#endif
