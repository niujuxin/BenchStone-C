#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>

#define MAX_LEN 100

int main(int argc, char **argv);

#endif
