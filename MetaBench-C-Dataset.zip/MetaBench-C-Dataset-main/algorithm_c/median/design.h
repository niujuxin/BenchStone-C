#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>

int main();

#endif
