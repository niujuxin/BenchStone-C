#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

void merge(int *a, int l, int r, int n);

#endif
