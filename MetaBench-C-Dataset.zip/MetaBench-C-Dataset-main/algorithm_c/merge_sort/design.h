#ifndef DESIGN_H
#define DESIGN_H

void merge_sort(int *a, int n, int l, int r);
void swap(int *a, int *b);

#endif
