#ifndef DESIGN_H
#define DESIGN_H

void mergesort(int x[], int n);

#endif
