#ifndef DESIGN_H
#define DESIGN_H

#define NULL ((void *)0)

struct Node {
    int data;
    struct Node *next;
};

void printMiddle(struct Node *head);

#endif
