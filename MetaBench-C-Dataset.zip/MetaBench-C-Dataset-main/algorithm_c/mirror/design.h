#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

void saisie(char *chaine);
char *miroir(char *chaine);
int compte(char *s);

#endif
