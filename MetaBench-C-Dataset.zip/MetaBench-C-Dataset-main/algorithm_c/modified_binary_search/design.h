#ifndef DESIGN_H
#define DESIGN_H

void modifiedBinarySearch(const int **mat, int n, int m, int x);
int binarySearch(const int **mat, int i, int j_low, int j_high, int x);

#endif
