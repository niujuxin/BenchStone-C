#ifndef DESIGN_H
#define DESIGN_H

#define i2c(i) x[i][depth]
#define med3(a, b, c) med3func(a, b, c, depth)
#define swap(a, b)      \
    {                   \
        char *t = x[a]; \
        x[a] = x[b];    \
        x[b] = t;       \
    }
#define swap2(a, b)  \
    {                \
        t = *(a);    \
        *(a) = *(b); \
        *(b) = t;    \
    }
#define ptr2char(i) (*(*(i) + depth))
#define min(a, b) ((a) <= (b) ? (a) : (b))

void ssort1main(char *x[], int n);
void ssort2main(char **a, int n);

void ssort1(char *x[], int n, int depth);
void ssort2(char **a, int n, int depth);

void vecswap(int i, int j, int n, char *x[]);
void inssort(char **a, int n, int d);
void vecswap2(char **a, char **b, int n);

char **med3func(char **a, char **b, char **c, int depth);

int rand(void);

#endif
