#ifndef DESIGN_H
#define DESIGN_H

#include <string.h>

void naive_search(char *str, char *pattern);

#endif
