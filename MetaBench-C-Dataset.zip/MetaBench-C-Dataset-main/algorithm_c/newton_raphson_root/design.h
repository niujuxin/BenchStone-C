#ifndef DESIGN_H
#define DESIGN_H

#include <complex.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define ACCURACY 1e-6

double complex func(double complex x);
double complex d_func(double complex x);

int main(int argc, char **argv);

#endif
