#ifndef DESIGN_H
#define DESIGN_H

#define NULL ((void *)0)

typedef int bool;

typedef struct node node;
struct node
{
    int ID;
    int AT;
    int BT;
    int priority;
    int CT;
    int WT;
    int TAT;
    node *next;
};

void *malloc(unsigned long size);
void free(void *ptr);
int l_length(node **root);
float calculate_ct(node **root);
void update(node **root, int id, int ct, int wt, int tat);
bool compare(node *a, node *b);
void insert(node **root, int id, int at, int bt, int prior);
void delete(node **root, int id);

#endif /* DESIGN_H */
