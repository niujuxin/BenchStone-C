#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <math.h>

long octalToBinary(int octalnum);

double pow(double x, double y);

#endif
