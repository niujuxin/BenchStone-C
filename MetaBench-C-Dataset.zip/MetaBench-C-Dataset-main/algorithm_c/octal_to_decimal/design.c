#include "design.h"

double pow(double base, double exponent)
{
    double result = 1.0;
    int exp_int = (int)exponent;
    int i;
    
    if (exponent == 0.0)
        return 1.0;
    
    if (exponent < 0.0)
    {
        base = 1.0 / base;
        exp_int = -exp_int;
    }
    
    for (i = 0; i < exp_int; i++)
    {
        result *= base;
    }
    
    return result;
}

int convertValue(int num, int i) { return num * pow(8, i); }

long long toDecimal(int octal_value)
{
    int decimal_value = 0, i = 0;

    while (octal_value)
    {
        // Extracts right-most digit and then multiplies by 8^i
        decimal_value += convertValue(octal_value % 10, i++);

        // Shift right in base 10
        octal_value /= 10;
    }

    return decimal_value;
}
