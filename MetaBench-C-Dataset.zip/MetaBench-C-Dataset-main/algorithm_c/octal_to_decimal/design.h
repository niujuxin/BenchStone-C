#ifndef DESIGN_H
#define DESIGN_H

long long toDecimal(int octal_value);
int convertValue(int num, int i);
double pow(double base, double exponent);

#endif
