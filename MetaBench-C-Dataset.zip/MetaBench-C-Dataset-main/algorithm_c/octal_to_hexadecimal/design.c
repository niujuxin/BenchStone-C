#include "design.h"

double pow(double base, double exponent) {
    double result = 1.0;
    long exp_int;
    int is_negative = 0;
    
    if (exponent < 0) {
        is_negative = 1;
        exponent = -exponent;
    }
    
    exp_int = (long)exponent;
    
    for (long i = 0; i < exp_int; i++) {
        result *= base;
    }
    
    if (is_negative) {
        result = 1.0 / result;
    }
    
    return result;
}

long octalToDecimal(long octalValue){
    long decimalValue = 0;
    int i = 0;
    while (octalValue) {
        // Extracts right-most digit, multiplies it with 8^i, and increment i by 1
        decimalValue += (long)(octalValue % 10) * pow(8, i++);
        // Shift right in base 10
        octalValue /= 10;
    }
    return decimalValue;
}

char *octalToHexadecimal(long octalValue){
    char *hexadecimalValue = malloc(256 * sizeof(char));
    sprintf(hexadecimalValue, "%lX", octalToDecimal(octalValue));
    return hexadecimalValue;
}
