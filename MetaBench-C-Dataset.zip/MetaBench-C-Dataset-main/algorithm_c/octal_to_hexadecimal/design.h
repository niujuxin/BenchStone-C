#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

long octalToDecimal(long octalValue);
char *octalToHexadecimal(long octalValue);

double pow(double base, double exponent);

#endif
