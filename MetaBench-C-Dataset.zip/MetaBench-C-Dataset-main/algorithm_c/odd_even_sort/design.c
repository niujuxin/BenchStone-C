#include "design.h"

void swap(int32_t *first, int32_t *second)
{
    int32_t temp = *first;
    *first = *second;
    *second = temp;
}

void oddEvenSort(int *arr, int size)
{
    bool isSorted = false;
    while(!isSorted)
    {
        isSorted = true;
        int32_t i;

        // Even phase
        for(i = 0; i <= size - 2; i += 2)
        {
            if(arr[i] > arr[i + 1])
            {
                swap(&arr[i], &arr[i + 1]);
                isSorted = false;
            }
        }

        // Odd phase
        for(i = 1; i <= size - 2; i += 2)
        {
            if(arr[i] > arr[i + 1])
            {
                swap(&arr[i], &arr[i + 1]);
                isSorted = false;
            }
        }
    }
}
