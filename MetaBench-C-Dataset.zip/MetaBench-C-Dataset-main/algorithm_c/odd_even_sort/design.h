#ifndef DESIGN_H
#define DESIGN_H

#include <stdint.h>
#include <stdbool.h>

void oddEvenSort(int *arr, int size);
void swap(int32_t *first, int32_t *second);

#endif
