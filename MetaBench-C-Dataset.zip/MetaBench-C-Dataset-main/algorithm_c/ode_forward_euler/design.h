#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define order 2

double forward_euler(double step_size, double X0, double X_MAX, double *Y0, int save_to_file);
void exact_solution(double *x, double *y);
void forward_euler_step(const double dx, const double *x, double *y, double *dy);
void problem(const double *x, double *y, double *dy);

#endif
