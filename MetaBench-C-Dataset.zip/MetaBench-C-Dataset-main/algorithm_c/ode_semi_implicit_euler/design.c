#include "design.h"

void problem(const double *x, double *y, double *dy)
{
    const double omega = 1.F;       // some const for the problem
    dy[0] = y[1];                   // x dot
    dy[1] = -omega * omega * y[0];  // y dot
}

void semi_implicit_euler_step(double dx, double *x, double *y, double *dy)
{
    int o;

    problem(x, y, dy);   // update dy once
    y[0] += dx * dy[0];  // update y0

    problem(x, y, dy);  // update dy once more

    for (o = 1; o < order; o++)
        y[o] += dx * dy[o];  // update remaining using new dy
    *x += dx;
}

void exact_solution(const double *x, double *y)
{
    y[0] = cos(x[0]);
    y[1] = -sin(x[0]);
}

double semi_implicit_euler(double dx, double x0, double x_max, double *y,
                           char save_to_file)
{
    double dy[order];

    FILE *fp = NULL;
    if (save_to_file)
    {
        fp = fopen("semi_implicit_euler.csv", "w+");
        if (fp == NULL)
        {
            perror("Error! ");
            return -1;
        }
    }

    /* start integration */
    clock_t t1 = clock();
    double x = x0;
    do  // iterate for each step of independent variable
    {
        if (save_to_file && fp)
            fprintf(fp, "%.4g,%.4g,%.4g\n", x, y[0], y[1]);  // write to file
        semi_implicit_euler_step(dx, &x, y, dy);  // perform integration
        x += dx;                                  // update step
    } while (x <= x_max);  // till upper limit of independent variable
    /* end of integration */
    clock_t t2 = clock();

    if (save_to_file && fp)
        fclose(fp);

    return (double)(t2 - t1) / CLOCKS_PER_SEC;
}

int main(int argc, char *argv[])
{
    double X0 = 0.f;          /* initial value of x0 */
    double X_MAX = 10.F;      /* upper limit of integration */
    double Y0[] = {1.f, 0.f}; /* initial value Y = y(x = x_0) */
    double step_size;

    if (argc == 1)
    {
        printf("\nEnter the step size: ");
        scanf("%lg", &step_size);
    }
    else
        // use commandline argument as independent variable step size
        step_size = atof(argv[1]);

    // get approximate solution
    double total_time = semi_implicit_euler(step_size, X0, X_MAX, Y0, 1);
    printf("\tTime = %.6g ms\n", total_time);

    /* compute exact solution for comparion */
    FILE *fp = fopen("exact.csv", "w+");
    if (fp == NULL)
    {
        perror("Error! ");
        return -1;
    }
    double x = X0;
    double *y = &(Y0[0]);
    printf("Finding exact solution\n");
    clock_t t1 = clock();

    do
    {
        fprintf(fp, "%.4g,%.4g,%.4g\n", x, y[0], y[1]);  // write to file
        exact_solution(&x, y);
        x += step_size;
    } while (x <= X_MAX);

    clock_t t2 = clock();
    total_time = (t2 - t1) / CLOCKS_PER_SEC;
    printf("\tTime = %.6g ms\n", total_time);
    fclose(fp);

    return 0;
}
