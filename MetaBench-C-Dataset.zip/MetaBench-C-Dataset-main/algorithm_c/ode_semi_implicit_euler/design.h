#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define order 2

double semi_implicit_euler(double dx, double x0, double x_max, double *y,
                           char save_to_file);

void semi_implicit_euler_step(double dx, double *x, double *y, double *dy);

void exact_solution(const double *x, double *y);

void problem(const double *x, double *y, double *dy);

#endif
