#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

#define len 5

int binarySearch(int *array, int size, int value);

#endif
