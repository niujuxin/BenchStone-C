#ifndef DESIGN_H
#define DESIGN_H

#include <stdbool.h>

bool isPalindrome(int x);

#endif
