#ifndef DESIGN_H
#define DESIGN_H

void pancakeSort(int *arr, int n);

#endif
