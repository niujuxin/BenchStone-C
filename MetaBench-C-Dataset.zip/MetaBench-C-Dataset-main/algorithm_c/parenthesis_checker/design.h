#ifndef DESIGN_H
#define DESIGN_H

#include <stdio.h>

#define SIZE 1000

struct node
{
    int data;
    struct node *link;
};

int isBalanced(char *s);
void destroyStack(void);
char pop(void);
void push(char x);

extern int c;
extern struct node *head;

#endif
