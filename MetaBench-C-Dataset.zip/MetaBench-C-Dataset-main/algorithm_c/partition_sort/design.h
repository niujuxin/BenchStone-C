#ifndef DESIGN_H
#define DESIGN_H

void partitionSort(int arr[], int low, int high);
int partition(int arr[], int low, int high);
void swap(int *a, int *b);

#endif
