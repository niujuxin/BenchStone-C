#include "design.h"

void patienceSort(int *array, int length) {
    // An array of pointers used to store each pile
    int* *piles = (int* *) malloc(sizeof(int*) * length);
    for (int i = 0; i < length; ++i) {
        piles[i] = malloc(sizeof(int) * length);
    }

    // pileSizes keep track of the indices of each pile's topmost element, hence 0 means only one element
    // Note how calloc() is used to initialize the sizes of all piles to zero
    int *pileSizes = (int*) calloc(length,sizeof(int));

    // This initializes the first pile, note how using an array of pointers allowed us to access elements through two subscripts
    // The first subscript indicates which pile we are accessing, the second subscript indicates the location being accessed in that pile
    piles[0][0] = array[0];
    int pileCount = 1;

    for (int i = 1; i < length; ++i) {
        // This will be used to keep track whether an element has been added to an existing pile
        int flag = 1;

        for (int j = 0; j < pileCount; ++j) {
            if(piles[j][pileSizes[j]] > array[i]) {
                // We have found a pile this element can be added to
                piles[j][pileSizes[j] + 1] = array[i];
                pileSizes[j]++;
                flag--;
                break;
            }
        }

        if(flag) {
            // The element in question can not be added to any existing piles, creating a new pile
            piles[pileCount][0] = array[i];
            pileCount++;
        }
    }

    // This will keep track of the minimum value of all 'exposed' elements and which pile that value is from
    int min, minLocation;

    for (int i = 0; i < length; ++i) {
        // Since there's no guarantee the first pile will be depleted slower than other piles,
        // Example: when all elements are equal, in that case the first pile will be depleted immediately
        // We can't simply initialize min to the top most element of the first pile,
        // this loop finds a value to initialize min to.
        for (int j = 0; j < pileCount; ++j) {
            if(pileSizes[j] < 0) {
                continue;
            }
            min = piles[j][pileSizes[j]];
            minLocation = j;
            break;
        }

        for (int j = 0; j < pileCount; ++j) {
            if(pileSizes[j] < 0) {
                continue;
            }
            if(piles[j][pileSizes[j]] < min) {
                min = piles[j][pileSizes[j]];
                minLocation = j;
            }
        }

        array[i] = min;
        pileSizes[minLocation]--;
    }

    // Deallocate memory
    free(pileSizes);
    for (int i = 0; i < length; ++i) {
        free(piles[i]);
    }
    free(piles);
}
