#ifndef DESIGN_H
#define DESIGN_H

#include <stdlib.h>

void patienceSort(int *array, int length);

#endif
