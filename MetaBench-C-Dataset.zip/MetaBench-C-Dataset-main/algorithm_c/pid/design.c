#include "design.h"

float pid_step(struct pid *controller, float dt, float error)
{
    // Calculate p term
    float p = error * controller->kP;

    // Calculate i term
    controller->integral += error * dt * controller->kI;

    // Calculate d term, taking care to not divide by zero
    float d =
        dt == 0 ? 0 : ((error - controller->lastError) / dt) * controller->kD;
    controller->lastError = error;

    return p + controller->integral + d;
}

int main()
{
    struct pid controller = {.lastError = 0, .integral = 0};

    float time_step = 1;

    float error_value;
    while (1)
    {
        error_value = 0;

        float output = pid_step(&controller, time_step, error_value);
    }
}
