#ifndef DESIGN_H
#define DESIGN_H

struct pid {
    float kP;
    float kI;
    float kD;
    float lastError;
    float integral;
};

float pid_step(struct pid *controller, float dt, float error);

#endif
